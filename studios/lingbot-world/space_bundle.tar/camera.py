"""Camera-trajectory helpers for the LingBot-World-V2 demo.

The model is conditioned on a *camera path*: `wan/image2video.py` reads
`poses.npy` (per-frame OpenCV camera-to-world 4x4 matrices) and
`intrinsics.npy` (per-frame `[fx, fy, cx, cy]` for a 832x480 frame) from an
"action directory", converts the poses to frame-to-frame relative motion
(`compute_relative_poses(..., framewise=True)`) and turns them into Plucker
embeddings.

Because the pipeline only ever sees *frame-to-frame deltas* (with the
translation part rescaled so the largest step has unit norm), a synthetic path
is fully described by a single delta transform applied repeatedly:

    c2w[i] = delta ** i

which is exactly what `synthesize_poses` below builds.
"""

from __future__ import annotations

import os
import tempfile

import numpy as np

# Intrinsics of the authors' own real-world captures (examples/03 and /04),
# expressed for a 832x480 frame: ~90 degrees horizontal field of view.
DEFAULT_INTRINSICS = np.array(
    [415.5298, 415.6922, 415.77786, 239.77779], dtype=np.float32
)

FPS = 16  # wan_shared_cfg.sample_fps

# Recorded trajectories shipped with the official repository.
RECORDED_PATHS = {
    "Recorded · dragon flight (official)": "examples/00",
    "Recorded · Stonehenge sweep (official)": "examples/01",
    "Recorded · city walk (official)": "examples/02",
    "Recorded · lakeside drift (official)": "examples/03",
    "Recorded · Great Wall walk (official)": "examples/04",
}

# Synthetic motions. `t` is a unit translation in the *camera* frame
# (x right, y down, z forward - OpenCV convention) applied every frame;
# `rot` is (pitch, yaw, roll) in units of the user-selected turn rate.
SYNTHETIC_PATHS = {
    "Dolly forward": dict(t=(0.0, 0.0, 1.0), rot=(0.0, 0.0, 0.0)),
    "Dolly backward": dict(t=(0.0, 0.0, -1.0), rot=(0.0, 0.0, 0.0)),
    "Truck left": dict(t=(-1.0, 0.0, 0.0), rot=(0.0, 0.0, 0.0)),
    "Truck right": dict(t=(1.0, 0.0, 0.0), rot=(0.0, 0.0, 0.0)),
    "Crane up": dict(t=(0.0, -1.0, 0.0), rot=(0.0, 0.0, 0.0)),
    "Crane down": dict(t=(0.0, 1.0, 0.0), rot=(0.0, 0.0, 0.0)),
    "Pan left": dict(t=(0.0, 0.0, 0.0), rot=(0.0, -1.0, 0.0)),
    "Pan right": dict(t=(0.0, 0.0, 0.0), rot=(0.0, 1.0, 0.0)),
    "Tilt up": dict(t=(0.0, 0.0, 0.0), rot=(1.0, 0.0, 0.0)),
    "Tilt down": dict(t=(0.0, 0.0, 0.0), rot=(-1.0, 0.0, 0.0)),
    "Orbit left": dict(t=(-1.0, 0.0, 0.0), rot=(0.0, 1.0, 0.0)),
    "Orbit right": dict(t=(1.0, 0.0, 0.0), rot=(0.0, -1.0, 0.0)),
    "Fly forward, pan left": dict(t=(0.0, 0.0, 1.0), rot=(0.0, -1.0, 0.0)),
    "Fly forward, pan right": dict(t=(0.0, 0.0, 1.0), rot=(0.0, 1.0, 0.0)),
    "Hold still": dict(t=(0.0, 0.0, 0.0), rot=(0.0, 0.0, 0.0)),
}

CAMERA_CHOICES = list(SYNTHETIC_PATHS) + list(RECORDED_PATHS)


def _rot_x(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]], dtype=np.float64)


def _rot_y(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], dtype=np.float64)


def _rot_z(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=np.float64)


def synthesize_poses(motion: str, num_frames: int, turn_rate_deg_per_s: float) -> np.ndarray:
    """Build `num_frames` OpenCV camera-to-world poses for a named motion.

    Args:
        motion: a key of `SYNTHETIC_PATHS`.
        num_frames: number of video frames to cover.
        turn_rate_deg_per_s: rotation speed in degrees per second of video.

    Returns:
        float32 array of shape [num_frames, 4, 4].
    """
    spec = SYNTHETIC_PATHS[motion]
    step = np.deg2rad(turn_rate_deg_per_s) / FPS
    pitch, yaw, roll = (v * step for v in spec["rot"])

    rot = _rot_x(pitch) @ _rot_y(yaw) @ _rot_z(roll)
    delta = np.eye(4, dtype=np.float64)
    delta[:3, :3] = rot
    delta[:3, 3] = np.asarray(spec["t"], dtype=np.float64)

    poses = np.zeros((num_frames, 4, 4), dtype=np.float64)
    acc = np.eye(4, dtype=np.float64)
    for i in range(num_frames):
        poses[i] = acc
        acc = acc @ delta
    return poses.astype(np.float32)


def make_action_dir(motion: str, num_frames: int, turn_rate_deg_per_s: float) -> str:
    """Materialise a camera path as an action directory the pipeline can read.

    Recorded motions resolve to the official `examples/NN` directory directly;
    synthetic ones are written to a fresh temporary directory (so concurrent
    requests never clobber each other).
    """
    if motion in RECORDED_PATHS:
        return RECORDED_PATHS[motion]

    poses = synthesize_poses(motion, num_frames, turn_rate_deg_per_s)
    intrinsics = np.tile(DEFAULT_INTRINSICS, (num_frames, 1))

    path = tempfile.mkdtemp(prefix="campath_")
    np.save(os.path.join(path, "poses.npy"), poses)
    np.save(os.path.join(path, "intrinsics.npy"), intrinsics)
    return path


def max_frames_for(motion: str) -> int:
    """How many frames a motion can drive (recorded paths have finite length)."""
    if motion in RECORDED_PATHS:
        poses = np.load(os.path.join(RECORDED_PATHS[motion], "poses.npy"), mmap_mode="r")
        return int(poses.shape[0])
    return 10_000
