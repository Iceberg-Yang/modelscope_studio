import copy

from easydict import EasyDict

from .wan_i2v_A14B import i2v_A14B

#------------------------ Wan I2V 1.3B (LingBot-World-V2 causal-fast) ------------------------#
# Same pipeline / schedule as the released A14B config; only the DiT backbone
# shape differs (dim 1536 / ffn 8960 / 12 heads / 30 layers), read straight off
# the published `robbyant/lingbot-world-v2-1.3b-causal-fast` safetensors.

i2v_1_3B = EasyDict(copy.deepcopy(dict(i2v_A14B)))
i2v_1_3B.__name__ = 'Config: LingBot-World-V2 I2V 1.3B'

i2v_1_3B.dim = 1536
i2v_1_3B.ffn_dim = 8960
i2v_1_3B.num_heads = 12
i2v_1_3B.num_layers = 30
