from . import configs, modules
from .image2video import WanI2VCausal
