---
title: LingBot-World-V2 1.3B
emoji: 🌍
colorFrom: green
colorTo: purple
sdk: gradio
sdk_version: 6.26.0
app_file: app.py
short_description: Camera-controlled image-to-video world model (1.3B)
python_version: "3.10"
startup_duration_timeout: 1h
license: cc-by-nc-sa-4.0
models:
  - robbyant/lingbot-world-v2-1.3b-causal-fast
---

# LingBot-World-V2 · 1.3B causal-fast

Interactive image-to-video **world model**. Give it one image, a prompt and a
camera path; it rolls the scene forward chunk-by-chunk with a causal KV cache,
so long clips stay temporally consistent. This is the *causal-fast* distilled
variant — 4 sampling steps per chunk instead of a full 40-step CFG loop.

- Model: [`robbyant/lingbot-world-v2-1.3b-causal-fast`](https://huggingface.co/robbyant/lingbot-world-v2-1.3b-causal-fast)
- Code: [github.com/robbyant/lingbot-world-v2](https://github.com/robbyant/lingbot-world-v2)

## How it's wired

The `wan/` directory is the authors' own inference package, carried over
essentially unchanged; the Space runs the same `WanI2VCausal` +
`WanModelFast` (`infer_mode="causal_fast"`) path as `run_fast.sh`, with
`local_attn_size=18`, `sink_size=6`, `chunk_size=3`, `shift=10.0` and the
default 4-step schedule. Only single-process/ZeroGPU adjustments were made
(optional FSDP / sequence-parallel imports made lazy, `torch.cuda.amp` →
`torch.amp`, plain `"cuda"` device placement).

The 1.3B repository ships the transformer shards only, so the umt5-xxl text
encoder, the Wan2.1 VAE and the tokenizer are fetched from the authors' 14B
release. The DiT `config.json` (dim 1536 / ffn 8960 / 12 heads / 30 layers,
`in_dim` 36) is reconstructed from the published safetensors headers.

## Camera control

The model is conditioned on **frame-to-frame camera motion** (Plücker
embeddings built from OpenCV camera-to-world poses). Two kinds of path are
offered:

- **Synthetic** — dolly / truck / crane / pan / tilt / orbit, generated as a
  repeated delta transform. The turn rate is adjustable; translation speed is
  fixed because the pipeline renormalises translations internally.
- **Recorded** — the five trajectories shipped in the official repository's
  `examples/`.

## Credits & licence

Model, inference code and the example images / camera trajectories are by the
LingBot-World-V2 authors and are used here under
**CC BY-NC-SA 4.0** (see `LICENSE.txt`) — non-commercial use only.
